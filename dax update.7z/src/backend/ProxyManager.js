const axios = require('axios');
const tcpPing = require('tcp-ping');
const fs = require('fs').promises;
const path = require('path');
const net = require('net');
const tls = require('tls');
const { SocksProxyAgent } = require('socks-proxy-agent');

class ProxyManager {
  constructor() {
    this.proxies = [];
    this.settings = {
      maxUsagePerProxy: 10,
      autoSwitch: true,
      testTimeout: 5000,
      currentProxyIndex: 0,
      concurrentTests: 200
    };
    this.stats = {
      total: 0,
      working: 0,
      failed: 0,
      testing: 0
    };
    // Track state for an active testing run
    this.testingRunActive = false;
    this.totalToTest = 0;
    this.completedInRun = 0;
    this.proxySourceUrls = [
      // API endpoints
      'https://www.proxy-list.download/api/v1/get?type=http',
      'https://www.proxy-list.download/api/v1/get?type=https',
      'https://www.proxy-list.download/api/v1/get?type=socks4',
      'https://www.proxy-list.download/api/v1/get?type=socks5',
      'https://api.proxyscrape.com/v3/free-proxy-list/get?request=displayproxies&protocol=http',
      'https://api.proxyscrape.com/v3/free-proxy-list/get?request=displayproxies&protocol=https',
      'https://api.proxyscrape.com/v3/free-proxy-list/get?request=displayproxies&protocol=socks4',
      'https://api.proxyscrape.com/v3/free-proxy-list/get?request=displayproxies&protocol=socks5',
      // Raw GitHub lists
      'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt',
      'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/https.txt',
      'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks4.txt',
      'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt',
      'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt',
      'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/https.txt',
      'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt',
      'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt',
      'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt',
      'https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies.txt',
      'https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt',
      'https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/http.txt',
      'https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/socks4.txt',
      'https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/socks5.txt',
      'https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTP_RAW.txt',
      'https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt',
      'https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS4_RAW.txt',
      'https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS5_RAW.txt',
      'https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt',
      // Other plain text providers
      'https://multiproxy.org/txt_all/proxy.txt',
      'https://proxyspace.pro/http.txt',
      'https://proxyspace.pro/https.txt',
      'https://proxyspace.pro/socks4.txt',
      'https://proxyspace.pro/socks5.txt'
    ];

    // HTML pages to scrape for IP:port pairs (fallback, best-effort)
    this.websiteSourceUrls = [
      'https://free-proxy-list.net/',
      'https://www.sslproxies.org/',
      'https://www.proxynova.com/proxy-server-list/'
    ];
  }

  async fetchProxies() {
    console.log('Fetching proxies from multiple sources...');
    const allProxies = new Set();

    // 1) Raw/text endpoints (GitHub/APIs)
    for (const url of this.proxySourceUrls) {
      try {
        const response = await axios.get(url, { timeout: 15000 });
        const proxies = this.parseProxyList(response.data, this.getTypeFromUrl(url));
        proxies.forEach(proxy => allProxies.add(JSON.stringify(proxy)));
        console.log(`Fetched ${proxies.length} proxies from ${url}`);
      } catch (error) {
        console.error(`Failed to fetch from ${url}:`, error.message);
      }
    }

    // 2) HTML pages scraping (best-effort)
    for (const url of this.websiteSourceUrls) {
      try {
        const response = await axios.get(url, { timeout: 15000, headers: { 'User-Agent': 'Mozilla/5.0' } });
        const scraped = this.extractProxiesFromText(response.data);
        scraped.forEach(({ ip, port }) => {
          const proxy = { ip, port, type: 'HTTP', latency: null };
          allProxies.add(JSON.stringify(proxy));
        });
        console.log(`Scraped ${scraped.length} proxies from ${url}`);
      } catch (error) {
        console.error(`Failed to scrape from ${url}:`, error.message);
      }
    }

    const uniqueProxies = Array.from(allProxies).map(proxy => JSON.parse(proxy));
    
    this.proxies = uniqueProxies.map((proxy, index) => ({
      id: `proxy_${index}_${Date.now()}`,
      ...proxy,
      enabled: true,
      usageCount: 0,
      lastChecked: null,
      status: 'untested',
      country: this.getCountryFromIP(proxy.ip) // Quick country guess
    }));
  
    this.updateStats();
    
    // Start testing proxies in batches with progress reporting
    this.testProxiesInBatches();
  
    return this.proxies;
  }
  
  // Add this method for quick country detection based on IP ranges
  getCountryFromIP(ip) {
    const firstOctet = parseInt(ip.split('.')[0]);
    
    // Very rough approximation based on IP ranges
    if (firstOctet >= 1 && firstOctet <= 50) return 'US';
    if (firstOctet >= 51 && firstOctet <= 100) return 'EU';
    if (firstOctet >= 101 && firstOctet <= 150) return 'AS';
    if (firstOctet >= 151 && firstOctet <= 200) return 'US';
    if (firstOctet >= 201 && firstOctet <= 255) return 'GLOBAL';
    
    return 'UNKNOWN';
  }

  parseProxyList(data, defaultType = 'HTTP') {
    const lines = data.toString().split('\n').filter(line => line.trim());
    const proxies = [];

    for (const line of lines) {
      const cleanLine = line.trim();
      if (cleanLine && !cleanLine.startsWith('#')) {
        const match = cleanLine.match(/^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d{1,5})/);
        if (match) {
          proxies.push({
            ip: match[1],
            port: match[2],
            type: defaultType,
            latency: null
          });
        }
      }
    }

    return proxies;
  }

  // Extract proxies from arbitrary text/HTML using regex
  extractProxiesFromText(data) {
    try {
      const text = data.toString();
      const matches = text.matchAll(/\b(\d{1,3}(?:\.\d{1,3}){3}):(\d{2,5})\b/g);
      const results = [];
      for (const m of matches) {
        const ip = m[1];
        const port = m[2];
        // Basic octet range validation
        const ok = ip.split('.').every(o => {
          const n = parseInt(o, 10);
          return n >= 0 && n <= 255;
        });
        if (ok) results.push({ ip, port });
      }
      return results;
    } catch (_) {
      return [];
    }
  }

  getTypeFromUrl(url) {
    if (url.includes('socks4')) return 'SOCKS4';
    if (url.includes('socks5')) return 'SOCKS5';
    if (url.includes('https')) return 'HTTPS';
    return 'HTTP';
  }

  async detectCountry(ip) {
    try {
      // Using a free IP geolocation API
      const response = await axios.get(`http://ip-api.com/json/${ip}`, { 
        timeout: 2000 
      });
      
      if (response.data && response.data.status === 'success') {
        return response.data.countryCode || response.data.country || 'UNKNOWN';
      }
    } catch (error) {
      // Silent fail - don't log to avoid spam
    }
    return 'UNKNOWN';
  }

  async testProxy(proxy) {
    return new Promise(async (resolve) => {
      // Detect country if not already set (best-effort, non-blocking on failure)
      if (!proxy.country || proxy.country === 'UNKNOWN') {
        this.detectCountry(proxy.ip)
          .then(cc => { proxy.country = cc; })
          .catch(() => {});
      }

      const targetHost = '1.1.1.1';
      const targetPort = 443;
      const timeoutMs = this.settings.testTimeout || 5000;

      const categorize = (lat) => {
        if (typeof lat !== 'number') return 'failed';
        if (lat < 500) return 'working';
        if (lat < 2000) return 'slow';
        return 'failed';
      };

      const tryHTTPPlain = () => {
        return new Promise((res) => {
          const attemptStart = Date.now();
          const socket = new net.Socket();
          let finished = false;
          let hardTimer = null;
          const done = (ok, latency) => {
            if (finished) return;
            finished = true;
            if (hardTimer) { clearTimeout(hardTimer); hardTimer = null; }
            try { socket.removeAllListeners(); socket.destroy(); } catch (_) {}
            res({ ok, latency, status: categorize(latency) });
          };
          socket.setTimeout(timeoutMs);
          hardTimer = setTimeout(() => done(false), timeoutMs + 1000);
          socket.once('connect', () => {
            const connectReq = `CONNECT ${targetHost}:${targetPort} HTTP/1.1\r\nHost: ${targetHost}:443\r\nConnection: keep-alive\r\n\r\n`;
            try { socket.write(connectReq); } catch (_) { return done(false); }
          });
          let response = '';
          socket.on('data', (chunk) => {
            response += chunk.toString('utf8');
            const match = response.match(/^HTTP\/1\.(?:0|1)\s+(\d{3})/i);
            if (match) {
              const code = parseInt(match[1], 10);
              const latency = Date.now() - attemptStart;
              if (code === 200) return done(true, latency);
              return done(false);
            }
            if (response.length > 2048) return done(false);
          });
          socket.once('timeout', () => done(false));
          socket.once('error', () => done(false));
          socket.once('end', () => done(false));
          socket.once('close', () => done(false));
          try { socket.connect(parseInt(proxy.port), proxy.ip); } catch (_) { return done(false); }
        });
      };

      const tryHTTPSTLS = () => {
        return new Promise((res) => {
          const attemptStart = Date.now();
          let finished = false;
          let hardTimer = null;
          let rawSocket;
          let tlsSocket;
          const done = (ok, latency) => {
            if (finished) return;
            finished = true;
            if (hardTimer) { clearTimeout(hardTimer); hardTimer = null; }
            try { rawSocket && rawSocket.removeAllListeners(); rawSocket && rawSocket.destroy(); } catch (_) {}
            try { tlsSocket && tlsSocket.removeAllListeners(); tlsSocket && tlsSocket.destroy(); } catch (_) {}
            res({ ok, latency, status: categorize(latency) });
          };

          const fail = () => done(false);

          try {
            // Create raw TCP socket and attach handlers BEFORE connecting to avoid race conditions
            rawSocket = new net.Socket({ allowHalfOpen: false });
            rawSocket.setTimeout(timeoutMs);
            rawSocket.once('error', fail);
            rawSocket.once('timeout', fail);
            rawSocket.once('end', fail);
            rawSocket.once('close', fail);
            hardTimer = setTimeout(fail, timeoutMs + 1000);

            rawSocket.connect(parseInt(proxy.port), proxy.ip, () => {
              try {
                // Layer TLS on the already-connected socket
                tlsSocket = tls.connect({
                  socket: rawSocket,
                  rejectUnauthorized: false,
                  // Do not set servername to an IP to avoid RFC 6066 deprecation warning
                  servername: undefined,
                  timeout: timeoutMs
                });
              } catch (_) {
                return fail();
              }

              // Attach TLS handlers immediately
              tlsSocket.once('error', fail);
              tlsSocket.once('timeout', fail);
              tlsSocket.once('end', fail);
              tlsSocket.once('close', fail);

              tlsSocket.once('secureConnect', () => {
                const connectReq = `CONNECT ${targetHost}:${targetPort} HTTP/1.1\r\nHost: ${targetHost}:443\r\nConnection: keep-alive\r\n\r\n`;
                try { tlsSocket.write(connectReq); } catch (_) { return fail(); }
              });

              let response = '';
              tlsSocket.on('data', (chunk) => {
                response += chunk.toString('utf8');
                const match = response.match(/^HTTP\/1\.(?:0|1)\s+(\d{3})/i);
                if (match) {
                  const code = parseInt(match[1], 10);
                  const latency = Date.now() - attemptStart;
                  if (code === 200) return done(true, latency);
                  return fail();
                }
                if (response.length > 2048) return fail();
              });
            });
          } catch (_) {
            return res({ ok: false, latency: null, status: 'failed' });
          }
        });
      };

      const trySOCKS5 = () => {
        return new Promise((res) => {
          const attemptStart = Date.now();
          const socket = new net.Socket();
          let finished = false;
          let stage = 'greet';
          let hardTimer = null;
          const done = (ok, latency) => {
            if (finished) return;
            finished = true;
            if (hardTimer) { clearTimeout(hardTimer); hardTimer = null; }
            try { socket.removeAllListeners(); socket.destroy(); } catch (_) {}
            res({ ok, latency, status: categorize(latency) });
          };
          socket.setTimeout(timeoutMs);
          hardTimer = setTimeout(() => done(false), timeoutMs + 1000);
          socket.once('connect', () => {
            // greeting: ver=5, nmethods=1, method=0(no auth)
            socket.write(Buffer.from([0x05, 0x01, 0x00]));
          });
          let buffer = Buffer.alloc(0);
          socket.on('data', (chunk) => {
            buffer = Buffer.concat([buffer, chunk]);
            if (stage === 'greet') {
              if (buffer.length >= 2) {
                if (buffer[0] !== 0x05 || buffer[1] !== 0x00) return done(false);
                buffer = buffer.slice(2);
                stage = 'connect';
                const addr = Buffer.from([1,1,1,1]);
                const port = Buffer.from([ (targetPort >> 8) & 0xff, targetPort & 0xff ]);
                const req = Buffer.concat([Buffer.from([0x05, 0x01, 0x00, 0x01]), addr, port]);
                socket.write(req);
              }
            } else if (stage === 'connect') {
              if (buffer.length >= 2) {
                // ver, rep
                if (buffer[0] !== 0x05 || buffer[1] !== 0x00) return done(false);
                const latency = Date.now() - attemptStart;
                return done(true, latency);
              }
            }
          });
          socket.once('timeout', () => done(false));
          socket.once('error', () => done(false));
          socket.once('end', () => done(false));
          socket.once('close', () => done(false));
          try { socket.connect(parseInt(proxy.port), proxy.ip); } catch (_) { return done(false); }
        });
      };

      const trySOCKS4 = () => {
        return new Promise((res) => {
          const attemptStart = Date.now();
          const socket = new net.Socket();
          let finished = false;
          let hardTimer = null;
          const done = (ok, latency) => {
            if (finished) return;
            finished = true;
            if (hardTimer) { clearTimeout(hardTimer); hardTimer = null; }
            try { socket.removeAllListeners(); socket.destroy(); } catch (_) {}
            res({ ok, latency, status: categorize(latency) });
          };
          socket.setTimeout(timeoutMs);
          hardTimer = setTimeout(() => done(false), timeoutMs + 1000);
          socket.once('connect', () => {
            const port = Buffer.from([ (targetPort >> 8) & 0xff, targetPort & 0xff ]);
            const addr = Buffer.from([1,1,1,1]);
            const userIdNull = Buffer.from([0x00]);
            const req = Buffer.concat([Buffer.from([0x04, 0x01]), port, addr, userIdNull]);
            socket.write(req);
          });
          let buffer = Buffer.alloc(0);
          socket.on('data', (chunk) => {
            buffer = Buffer.concat([buffer, chunk]);
            if (buffer.length >= 2) {
              // VN(0x00), CD(0x5A=granted)
              if (buffer[0] !== 0x00 || buffer[1] !== 0x5A) return done(false);
              const latency = Date.now() - attemptStart;
              return done(true, latency);
            }
          });
          socket.once('timeout', () => done(false));
          socket.once('error', () => done(false));
          socket.once('end', () => done(false));
          socket.once('close', () => done(false));
          try { socket.connect(parseInt(proxy.port), proxy.ip); } catch (_) { return done(false); }
        });
      };

      // Attempt across possible types; prefer reported type first
      const preferred = ((proxy.type || 'HTTP') + '').toUpperCase();
      const order = Array.from(new Set([preferred, 'HTTP', 'HTTPS', 'SOCKS5', 'SOCKS4']));
      let result = { ok: false };
      let detectedType = null;

      for (const t of order) {
        if (t === 'HTTP') {
          result = await tryHTTPPlain();
        } else if (t === 'HTTPS') {
          // Try TLS-to-proxy first, then fallback to plain if that fails quickly
          result = await tryHTTPSTLS();
          if (!result.ok) result = await tryHTTPPlain();
        } else if (t === 'SOCKS5') {
          result = await trySOCKS5();
        } else if (t === 'SOCKS4') {
          result = await trySOCKS4();
        } else {
          continue;
        }
        if (result.ok) { detectedType = t; break; }
      }

      // Apply results once
      if (result.ok) {
        const status = result.status;
        proxy.status = status;
        proxy.latency = typeof result.latency === 'number' ? Math.round(result.latency) : null;
        if (detectedType && proxy.type !== detectedType) proxy.type = detectedType;
      } else {
        proxy.status = 'failed';
        proxy.latency = null;
        proxy.type = 'UNKNOWN'; // Not HTTP/HTTPS/SOCKS4/SOCKS5 based on active probing
      }
      proxy.lastChecked = new Date().toISOString();
      this.updateStats();

      // Emit per-proxy completion for live UI updates
      try {
        if (global.mainWindow) {
          global.mainWindow.webContents.send('proxy-tested', {
            id: proxy.id,
            status: proxy.status,
            latency: proxy.latency,
            ip: proxy.ip,
            port: proxy.port,
            type: proxy.type,
            country: proxy.country,
            enabled: proxy.enabled,
            usageCount: proxy.usageCount
          });
        }
      } catch (_) {}

      // Emit per-proxy progress if in a managed batch run
      if (this.testingRunActive && this.totalToTest > 0) {
        this.completedInRun = Math.min(this.totalToTest, this.completedInRun + 1);
        try {
          if (global.mainWindow) {
            global.mainWindow.webContents.send('test-progress', {
              current: this.completedInRun,
              total: this.totalToTest,
              percentage: Math.round((this.completedInRun / this.totalToTest) * 100)
            });
          }
        } catch (_) {}
      }
      resolve(proxy);
    });
  }

  async testProxiesInBatches(batchSize = null) {
    const concurrentTests = batchSize || this.settings.concurrentTests || 200;
    const untested = this.proxies.filter(p => p.status === 'untested');
    
    console.log(`Testing ${untested.length} proxies with ${concurrentTests} concurrent tests...`);
    
    // Initialize run tracking
    this.testingRunActive = true;
    this.totalToTest = untested.length;
    this.completedInRun = 0;

    for (let i = 0; i < untested.length; i += concurrentTests) {
      const batch = untested.slice(i, i + concurrentTests);
      console.log(`Starting batch ${Math.floor(i / concurrentTests) + 1} containing ${batch.length} proxies...`);
      
      // Mark as testing
      batch.forEach(proxy => {
        proxy.status = 'testing';
      });
      this.updateStats();

      // Test batch
      const promises = batch.map(proxy => this.testProxy(proxy));
      try {
        await Promise.all(promises);
      } catch (e) {
        console.warn('One or more proxy tests threw unexpectedly:', e);
      }
      
      // Small delay between batches to prevent overwhelming the system
      await new Promise(resolve => setTimeout(resolve, 100));
      console.log(`Completed batch ${Math.floor(i / concurrentTests) + 1}. Progress: ${Math.min(i + batch.length, untested.length)}/${untested.length}`);
    }

    // Emit a final 100% progress event to ensure UI completion handling always fires
    if (global.mainWindow) {
      global.mainWindow.webContents.send('test-progress', {
        current: this.totalToTest,
        total: this.totalToTest,
        percentage: 100
      });
    }

    console.log('Proxy testing complete!');
    this.updateStats();
    this.testingRunActive = false;
    try {
      if (global.mainWindow) {
        global.mainWindow.webContents.send('notify', {
          message: `Proxy testing complete: ${this.stats.working} working / ${this.stats.total} total`,
          type: this.stats.working > 0 ? 'success' : 'warning',
          durationMs: 4500
        });
      }
    } catch (_) {}
  }

  toggleProxy(proxyId) {
    const proxy = this.proxies.find(p => p.id === proxyId);
    if (proxy) {
      proxy.enabled = !proxy.enabled;
    }
    return proxy;
  }

  getNextWorkingProxy() {
    const workingProxies = this.proxies.filter(p => 
      p.enabled && 
      p.status === 'working' && 
      p.usageCount < this.settings.maxUsagePerProxy
    );

    if (workingProxies.length === 0) {
      return null;
    }

    if (this.settings.autoSwitch) {
      const proxy = workingProxies[this.settings.currentProxyIndex % workingProxies.length];
      proxy.usageCount++;
      this.settings.currentProxyIndex++;
      return proxy;
    } else {
      const proxy = workingProxies[0];
      proxy.usageCount++;
      return proxy;
    }
  }

  getNextProxyForTunnel() {
    const candidates = this.proxies.filter(p =>
      p.enabled &&
      p.status === 'working' &&
      p.usageCount < this.settings.maxUsagePerProxy &&
      (p.type === 'HTTP' || p.type === 'HTTPS')
    );

    if (candidates.length === 0) return this.getNextWorkingProxy();

    const proxy = candidates[this.settings.currentProxyIndex % candidates.length];
    proxy.usageCount++;
    this.settings.currentProxyIndex++;
    return proxy;
  }

  updateStats() {
    this.stats = {
      total: this.proxies.length,
      working: this.proxies.filter(p => p.status === 'working').length,
      failed: this.proxies.filter(p => p.status === 'failed').length,
      testing: this.proxies.filter(p => p.status === 'testing').length,
      untested: this.proxies.filter(p => p.status === 'untested').length,
      slow: this.proxies.filter(p => p.status === 'slow').length
    };
  }

  getProxies() {
    return this.proxies;
  }

  getStats() {
    return this.stats;
  }

  updateSettings(newSettings) {
    this.settings = { ...this.settings, ...newSettings };
    return this.settings;
  }

  getSettings() {
    return this.settings;
  }

  async saveProxiesToFile() {
    const filePath = path.join(process.cwd(), 'proxies.json');
    await fs.writeFile(filePath, JSON.stringify(this.proxies, null, 2));
  }

  async loadProxiesFromFile() {
    try {
      const filePath = path.join(process.cwd(), 'proxies.json');
      const data = await fs.readFile(filePath, 'utf-8');
      this.proxies = JSON.parse(data);
      this.updateStats();
    } catch (error) {
      console.error('Failed to load proxies from file:', error);
    }
  }
}

module.exports = ProxyManager;