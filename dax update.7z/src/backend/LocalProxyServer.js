const http = require('http');
const httpProxy = require('http-proxy');
const url = require('url');
const net = require('net');

class LocalProxyServer {
  constructor() {
    this.server = null;
    this.proxy = httpProxy.createProxyServer({});
    this.port = 443;
    this.alternativePorts = [8443, 8080, 3128, 9999];
    this.interceptedRequests = [];
    this.isRunning = false;
    this.actualPort = null;
    this.totalDaxCalls = 0;
    this.activeDaxConnections = 0;
  }

  // Check if port is available
  async isPortAvailable(port) {
    return new Promise((resolve) => {
      const tester = net.createServer()
        .once('error', () => resolve(false))
        .once('listening', () => {
          tester.once('close', () => resolve(true)).close();
        })
        .listen(port, '127.0.0.1');
    });
  }

  // Find available port
  async findAvailablePort() {
    if (await this.isPortAvailable(this.port)) {
      return this.port;
    }

    console.log(`Port ${this.port} is in use, trying alternative ports...`);
    
    for (const port of this.alternativePorts) {
      if (await this.isPortAvailable(port)) {
        console.log(`Using alternative port: ${port}`);
        return port;
      }
    }

    throw new Error('No available ports found');
  }

  async start() {
    if (this.isRunning) {
      console.log('Proxy server is already running on port', this.actualPort);
      return Promise.resolve({ port: this.actualPort });
    }

    return new Promise(async (resolve, reject) => {
      try {
        const availablePort = await this.findAvailablePort();
        this.actualPort = availablePort;

        if (this.actualPort === 443) {
          // Raw TCP server for transparent TLS tunneling when bound to 443
          this.server = net.createServer((clientSocket) => {
            // Count connection
            this.totalDaxCalls++;
            this.activeDaxConnections++;

            const proxyManager = global.proxyManager;
            const proxy = proxyManager && proxyManager.getNextProxyForTunnel ? proxyManager.getNextProxyForTunnel() : null;

            if (!proxy) {
              // No upstream proxy; drop connection
              this.activeDaxConnections = Math.max(0, this.activeDaxConnections - 1);
              try { clientSocket.destroy(); } catch {}
              return;
            }

            const targetHost = 'walker.dax.cloud';
            const targetPort = 443;

            const proxySocket = net.connect({ host: proxy.ip, port: parseInt(proxy.port, 10) }, () => {
              const connectReq = `CONNECT ${targetHost}:${targetPort} HTTP/1.1\r\n` +
                                 `Host: ${targetHost}:${targetPort}\r\n` +
                                 `Proxy-Connection: Keep-Alive\r\n` +
                                 `Connection: Keep-Alive\r\n\r\n`;
              proxySocket.write(connectReq);
            });

            let responseBuffer = '';
            let cleaned = false;
            const cleanup = () => {
              if (cleaned) return;
              cleaned = true;
              this.activeDaxConnections = Math.max(0, this.activeDaxConnections - 1);
              try { proxySocket.destroy(); } catch {}
              try { clientSocket.destroy(); } catch {}
            };
            const onProxyData = (chunk) => {
              responseBuffer += chunk.toString('utf8');
              if (responseBuffer.indexOf('\r\n\r\n') !== -1) {
                proxySocket.removeListener('data', onProxyData);
                if (/^HTTP\/1\.[01] 200/i.test(responseBuffer)) {
                  // Start piping raw TLS data both ways
                  proxySocket.pipe(clientSocket);
                  clientSocket.pipe(proxySocket);
                  proxySocket.on('error', cleanup);
                  clientSocket.on('error', cleanup);
                  proxySocket.on('end', cleanup);
                  clientSocket.on('end', cleanup);
                  proxySocket.on('close', cleanup);
                  clientSocket.on('close', cleanup);
                } else {
                  // Upstream refused tunnel
                  cleanup();
                }
              }
            };
            proxySocket.on('data', onProxyData);
            proxySocket.on('error', cleanup);
            proxySocket.on('close', cleanup);
            proxySocket.setTimeout(10000);
            proxySocket.on('timeout', cleanup);

            // Ensure cleanup if the client disconnects before tunnel established
            clientSocket.on('error', cleanup);
            clientSocket.on('end', cleanup);
            clientSocket.on('close', cleanup);
            clientSocket.setTimeout(15000);
            clientSocket.on('timeout', cleanup);
          });
        } else {
          // HTTP server with optional CONNECT handling when not on 443
          this.server = http.createServer((req, res) => {
            const parsedUrl = url.parse(req.url);
            
            // Log intercepted request
            const request = {
              timestamp: new Date().toISOString(),
              method: req.method,
              url: req.url,
              headers: req.headers,
              host: req.headers.host
            };
            
            this.interceptedRequests.push(request);
            console.log(`Intercepted: ${req.method} ${req.url}`);

            // Keep only last 100 requests
            if (this.interceptedRequests.length > 100) {
              this.interceptedRequests = this.interceptedRequests.slice(-100);
            }

            // Check if this is for walker.dax.cloud
            if (req.headers.host && req.headers.host.includes('walker.dax.cloud')) {
              console.log('Intercepted walker.dax.cloud request:', req.url);
              
              const proxyManager = global.proxyManager;
              if (proxyManager) {
                const proxy = proxyManager.getNextWorkingProxy();
                if (proxy) {
                  console.log(`Routing through proxy: ${proxy.ip}:${proxy.port}`);
                  
                  this.proxy.web(req, res, {
                    target: `http://${proxy.ip}:${proxy.port}`,
                    changeOrigin: true
                  }, (error) => {
                    console.error('Proxy forward error:', error);
                    res.writeHead(502, { 'Content-Type': 'text/plain' });
                    res.end('Bad Gateway - Proxy Error');
                  });
                } else {
                  res.writeHead(503, { 'Content-Type': 'text/plain' });
                  res.end('No working proxies available');
                }
              } else {
                res.writeHead(500, { 'Content-Type': 'text/plain' });
                res.end('Proxy manager not initialized');
              }
            } else {
              // For other requests, just respond with a simple message
              res.writeHead(200, { 'Content-Type': 'text/plain' });
              res.end('Proxy server is running');
            }
          });

          // Handle HTTPS CONNECT requests from clients configured to use this as an HTTP proxy
          this.server.on('connect', (req, clientSocket, head) => {
            try {
              const [host, portStr] = (req.url || '').split(':');
              const port = parseInt(portStr || '443', 10);

              if (!host || !host.includes('walker.dax.cloud')) {
                clientSocket.write('HTTP/1.1 403 Forbidden\r\n\r\n');
                return clientSocket.end();
              }

              this.totalDaxCalls++;
              this.activeDaxConnections++;

              const proxyManager = global.proxyManager;
              const proxy = proxyManager && proxyManager.getNextProxyForTunnel ? proxyManager.getNextProxyForTunnel() : null;
              if (!proxy) {
                clientSocket.write('HTTP/1.1 503 Service Unavailable\r\n\r\n');
                this.activeDaxConnections = Math.max(0, this.activeDaxConnections - 1);
                return clientSocket.end();
              }

              const proxySocket = net.connect({ host: proxy.ip, port: parseInt(proxy.port, 10) }, () => {
                const connectReq = `CONNECT ${host}:${port} HTTP/1.1\r\n` +
                                   `Host: ${host}:${port}\r\n` +
                                   `Proxy-Connection: Keep-Alive\r\n` +
                                   `Connection: Keep-Alive\r\n\r\n`;
                proxySocket.write(connectReq);
              });

              proxySocket.setTimeout(10000);

              let responseBuffer = '';
              let cleaned = false;
              const cleanup = () => {
                if (cleaned) return;
                cleaned = true;
                this.activeDaxConnections = Math.max(0, this.activeDaxConnections - 1);
                try { proxySocket.destroy(); } catch {}
                try { clientSocket.destroy(); } catch {}
              };
              const onProxyData = (chunk) => {
                responseBuffer += chunk.toString('utf8');
                if (responseBuffer.indexOf('\r\n\r\n') !== -1) {
                  proxySocket.removeListener('data', onProxyData);
                  if (/^HTTP\/1\.[01] 200/i.test(responseBuffer)) {
                    clientSocket.write('HTTP/1.1 200 Connection Established\r\nProxy-agent: Dax-Local-Proxy\r\n\r\n');

                    if (head && head.length > 0) {
                      proxySocket.write(head);
                    }

                    proxySocket.pipe(clientSocket);
                    clientSocket.pipe(proxySocket);

                    proxySocket.on('error', cleanup);
                    clientSocket.on('error', cleanup);
                    proxySocket.on('end', cleanup);
                    clientSocket.on('end', cleanup);
                    proxySocket.on('close', cleanup);
                    clientSocket.on('close', cleanup);
                  } else {
                    try { clientSocket.write('HTTP/1.1 502 Bad Gateway\r\n\r\n'); } catch {}
                    cleanup();
                  }
                }
              };

              proxySocket.on('data', onProxyData);
              proxySocket.on('timeout', () => {
                try { clientSocket.write('HTTP/1.1 504 Gateway Timeout\r\n\r\n'); } catch {}
                cleanup();
              });
              proxySocket.on('error', () => {
                try { clientSocket.write('HTTP/1.1 502 Bad Gateway\r\n\r\n'); } catch {}
                cleanup();
              });
              clientSocket.on('error', cleanup);
            } catch (e) {
              try { clientSocket.write('HTTP/1.1 500 Internal Server Error\r\n\r\n'); } catch {}
              this.activeDaxConnections = Math.max(0, this.activeDaxConnections - 1);
              try { clientSocket.end(); } catch {}
            }
          });
        }

        this.proxy.on('error', (err, req, res) => {
          console.error('Proxy error:', err);
          if (res && res.writeHead) {
            res.writeHead(500, { 'Content-Type': 'text/plain' });
            res.end('Proxy error occurred');
          }
        });

        this.server.on('error', (error) => {
          console.error('Server error:', error);
          this.isRunning = false;
          reject(error);
        });

        this.server.listen(this.actualPort, '127.0.0.1', () => {
          console.log(`Local proxy server running on 127.0.0.1:${this.actualPort}`);
          this.isRunning = true;
          resolve({ port: this.actualPort });
        });

      } catch (error) {
        console.error('Failed to start server:', error);
        this.isRunning = false;
        reject(error);
      }
    });
  }

  stop() {
    if (this.server) {
      this.server.close(() => {
        console.log('Local proxy server stopped');
        this.isRunning = false;
        this.actualPort = null;
      });
      this.server = null;
    }
  }

  getInterceptedRequests() {
    return this.interceptedRequests;
  }

  clearInterceptedRequests() {
    this.interceptedRequests = [];
  }

  getStatus() {
    return {
      isRunning: this.isRunning,
      port: this.actualPort,
      requestCount: this.interceptedRequests.length,
      totalDaxCalls: this.totalDaxCalls,
      activeDaxConnections: this.activeDaxConnections
    };
  }

  // Add some test requests for demonstration
  addTestRequest() {
    this.interceptedRequests.push({
      timestamp: new Date().toISOString(),
      method: 'GET',
      url: '/test',
      headers: {},
      host: 'test.local'
    });
  }
}

module.exports = LocalProxyServer;