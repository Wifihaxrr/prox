
const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const hostile = require('hostile');
const { execSync } = require('child_process');
const ProxyManager = require('./src/backend/ProxyManager');
const LocalProxyServer = require('./src/backend/LocalProxyServer');

app.disableHardwareAcceleration();

// Global error handlers to avoid crashes from unexpected errors
process.on('uncaughtException', (err) => {
  try {
    console.error('Non-fatal error (uncaughtException) in main process:', err);
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('main-error', { type: 'uncaughtException', message: err.message, stack: err.stack });
    }
  } catch (_) {}
});

process.on('unhandledRejection', (reason, promise) => {
  try {
    console.error('Non-fatal error (unhandledRejection) in main process:', reason);
    if (mainWindow && !mainWindow.isDestroyed()) {
      const msg = reason && reason.message ? reason.message : String(reason);
      mainWindow.webContents.send('main-error', { type: 'unhandledRejection', message: msg });
    }
  } catch (_) {}
});

let mainWindow;
let proxyManager;
let localProxyServer;

// Check if running as administrator
function isAdmin() {
  try {
    execSync('net session', { stdio: 'ignore' });
    return true;
  } catch (e) {
    return false;
  }
}

// Request administrator privileges if not already admin
if (!isAdmin() && process.platform === 'win32') {
  console.log('Dax requires administrator privileges. Relaunching...');
  app.relaunch({ args: process.argv.slice(1).concat(['--relaunch']), execPath: process.execPath });
  app.quit();
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      webSecurity: false
    },
    icon: path.join(__dirname, 'assets/icon.ico'),
    frame: false,
    backgroundColor: '#1a1a2e',
    titleBarStyle: 'hidden',
    title: 'Dax - Proxy Manager',
    show: false
  });

  mainWindow.loadFile('src/frontend/index.html');

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    initializeBackend();
  });

  // Guard against renderer crashes or child process exits
  try {
    mainWindow.webContents.on('render-process-gone', (event, details) => {
      console.error('Renderer process gone:', details);
    });
    mainWindow.webContents.on('child-process-gone', (event, details) => {
      console.error('Child process gone:', details);
    });
  } catch (_) {}

  mainWindow.on('closed', () => {
    mainWindow = null;
    if (localProxyServer) {
      localProxyServer.stop();
    }
  });
}

async function initializeBackend() {
  // Initialize proxy manager
  proxyManager = new ProxyManager();
  
  // Initialize local proxy server  
  localProxyServer = new LocalProxyServer();
  
  // Make mainWindow globally accessible for progress updates
  global.mainWindow = mainWindow;
  global.proxyManager = proxyManager;
  
  // Auto-start the proxy server
  try {
    const result = await localProxyServer.start();
    console.log(`Dax proxy server auto-started on port ${result.port}`);
    
    // Modify hosts file if using port 443
    if (result.port === 443) {
      hostile.set('127.0.0.1', 'walker.dax.cloud');
      console.log('Hosts file modified successfully');
    }
    
    // Send status to renderer
    mainWindow.webContents.send('server-status', {
      isRunning: true,
      port: result.port
    });
  } catch (error) {
    console.error('Failed to auto-start proxy server:', error);
  }
  
  console.log('Dax initialized - ready for user commands');
}

// Add handler for updating performance settings
ipcMain.handle('update-performance-settings', async (event, settings) => {
  if (proxyManager) {
    proxyManager.settings.concurrentTests = settings.concurrentTests || 100;
    proxyManager.settings.testTimeout = settings.testTimeout || 3000;
    try {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('notify', {
          message: `Performance settings updated: concurrency ${proxyManager.settings.concurrentTests}, timeout ${proxyManager.settings.testTimeout} ms`,
          type: 'info',
          durationMs: 3000
        });
      }
    } catch (_) {}
    return { success: true, settings: proxyManager.settings };
  }
  return { success: false, error: 'Proxy manager not initialized' };
});

// Add a new IPC handler to start the proxy server manually
ipcMain.handle('start-proxy-server', async () => {
  try {
    const status = localProxyServer.getStatus();
    
    if (status.isRunning) {
      return { 
        success: true, 
        message: `Proxy server already running on port ${status.port}`,
        port: status.port,
        alreadyRunning: true
      };
    }

    const result = await localProxyServer.start();
    
    if (result.port === 443) {
      hostile.set('127.0.0.1', 'walker.dax.cloud');
      console.log('Hosts file modified for port 443');
    }
    
    return { 
      success: true, 
      message: `Proxy server started on port ${result.port}`,
      port: result.port,
      alreadyRunning: false
    };
  } catch (error) {
    console.error('Failed to start Dax proxy server:', error);
    return { success: false, error: error.message };
  }
});

// Add handler to get server status
ipcMain.handle('get-server-status', async () => {
  if (localProxyServer) {
    return localProxyServer.getStatus();
  }
  return { isRunning: false, port: null, requestCount: 0 };
});

// Add test endpoint for debugging
ipcMain.handle('add-test-request', async () => {
  if (localProxyServer) {
    localProxyServer.addTestRequest();
    return { success: true };
  }
  return { success: false };
});

// IPC Handlers
ipcMain.handle('fetch-proxies', async () => {
  const proxies = await proxyManager.fetchProxies();
  try {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('notify', {
        message: `Fetched ${proxies.length} proxies. Starting tests...`,
        type: 'info',
        durationMs: 3500
      });
    }
  } catch (_) {}
  return proxies;
});

ipcMain.handle('test-proxy', async (event, proxy) => {
  return await proxyManager.testProxy(proxy);
});

// Start batch proxy testing (fire-and-forget)
ipcMain.handle('test-proxies-batch', async (event, options) => {
  if (!proxyManager) {
    return { success: false, error: 'Proxy manager not initialized' };
  }
  const batchSize = options && options.batchSize ? options.batchSize : null;
  // Kick off asynchronously so the renderer isn't blocked
  setImmediate(() => {
    try {
      proxyManager.testProxiesInBatches(batchSize);
    } catch (e) {
      console.error('Failed to start batch testing:', e);
    }
  });
  const untested = proxyManager.getProxies().filter(p => p.status === 'untested').length;
  try {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('notify', {
        message: `Started batch testing ${untested} proxies with concurrency ${proxyManager.settings.concurrentTests}`,
        type: 'info',
        durationMs: 3500
      });
    }
  } catch (_) {}
  return {
    success: true,
    started: true,
    total: untested,
    concurrent: proxyManager.settings.concurrentTests,
    timeout: proxyManager.settings.testTimeout
  };
});

ipcMain.handle('get-proxies', async () => {
  return proxyManager.getProxies();
});

ipcMain.handle('toggle-proxy', async (event, proxyId) => {
  return proxyManager.toggleProxy(proxyId);
});

ipcMain.handle('get-stats', async () => {
  return proxyManager.getStats();
});

ipcMain.handle('get-intercepted-requests', async () => {
  try {
    // Get intercepted requests from the local proxy server
    const requests = localProxyServer ? localProxyServer.getInterceptedRequests() : [];
    return {
      requests: requests,
      count: requests.length
    };
  } catch (error) {
    console.error('Error getting intercepted requests:', error);
    return { requests: [], count: 0 };
  }
});

ipcMain.handle('get-settings', async () => {
  return proxyManager.getSettings();
});

ipcMain.handle('update-settings', async (event, settings) => {
  const updated = proxyManager.updateSettings(settings);
  try {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('notify', {
        message: 'Settings updated successfully',
        type: 'success',
        durationMs: 2500
      });
    }
  } catch (_) {}
  return updated;
});

// Window controls
ipcMain.on('minimize-window', () => {
  mainWindow.minimize();
});

ipcMain.on('maximize-window', () => {
  if (mainWindow.isMaximized()) {
    mainWindow.restore();
  } else {
    mainWindow.maximize();
  }
});

ipcMain.on('close-window', () => {
  app.quit();
});

// // Add GPU-related fixes
// app.commandLine.appendSwitch('disable-gpu');
// app.commandLine.appendSwitch('disable-gpu-sandbox');
// app.commandLine.appendSwitch('no-sandbox');
app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    // Clean up hosts file on exit
    try {
      hostile.remove('127.0.0.1', 'walker.dax.cloud');
      console.log('Dax: Hosts file cleaned up');
    } catch (error) {
      console.error('Dax: Failed to clean hosts file:', error);
    }
    app.quit();
  }
});

app.on('activate', () => {
  if (mainWindow === null) {
    createWindow();
  }
});