const axios = require('axios');
const { SocksProxyAgent } = require('socks-proxy-agent');
const tcpPing = require('tcp-ping');
const fs = require('fs').promises;
const path = require('path');

class ProxyManager {
  constructor() {
    this.proxies = [];
    this.settings = {
      maxUsagePerProxy: 10,
      autoSwitch: true,
      testTimeout: 3000, // Reduced from 5000
      currentProxyIndex: 0,
      concurrentTests: 100 // Increased for faster testing
    };
    this.stats = {
      total: 0,
      working: 0,
      failed: 0,
      testing: 0
    };
    this.proxySourceUrls = [
      'https://www.proxy-list.download/api/v1/get?type=http',
      'https://www.proxy-list.download/api/v1/get?type=https',
      'https://www.proxy-list.download/api/v1/get?type=socks4',
      'https://www.proxy-list.download/api/v1/get?type=socks5',
      'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt',
      'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks4.txt',
      'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt',
      'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt',
      'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/https.txt',
      'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt',
      'https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies.txt'
    ];
  }

  async fetchProxies() {
    console.log('Fetching proxies from multiple sources...');
    const allProxies = new Set();
  
    for (const url of this.proxySourceUrls) {
      try {
        const response = await axios.get(url, { timeout: 10000 });
        const proxies = this.parseProxyList(response.data, this.getTypeFromUrl(url));
        proxies.forEach(proxy => allProxies.add(JSON.stringify(proxy)));
        console.log(`Fetched ${proxies.length} proxies from ${url}`);
      } catch (error) {
        console.error(`Failed to fetch from ${url}:`, error.message);
      }
    }
  
    const uniqueProxies = Array.from(allProxies).map(proxy => JSON.parse(proxy));
    
    this.proxies = uniqueProxies.map((proxy, index) => ({
      id: `proxy_${index}_${Date.now()}`,
      ...proxy,
      enabled: true,
      usageCount: 0,
      lastChecked: null,
      status: 'untested',
      country: this.getCountryFromIP(proxy.ip) // Quick country guess
    }));
  
    this.updateStats();
    
    // Start testing proxies in batches with progress reporting
    this.testProxiesInBatches();
  
    return this.proxies;
  }
  
  // Add this method for quick country detection based on IP ranges
  getCountryFromIP(ip) {
    const firstOctet = parseInt(ip.split('.')[0]);
    
    // Very rough approximation based on IP ranges
    if (firstOctet >= 1 && firstOctet <= 50) return 'US';
    if (firstOctet >= 51 && firstOctet <= 100) return 'EU';
    if (firstOctet >= 101 && firstOctet <= 150) return 'AS';
    if (firstOctet >= 151 && firstOctet <= 200) return 'US';
    if (firstOctet >= 201 && firstOctet <= 255) return 'GLOBAL';
    
    return 'UNKNOWN';
  }

  parseProxyList(data, defaultType = 'HTTP') {
    const lines = data.toString().split('\n').filter(line => line.trim());
    const proxies = [];

    for (const line of lines) {
      const cleanLine = line.trim();
      if (cleanLine && !cleanLine.startsWith('#')) {
        const match = cleanLine.match(/^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d{1,5})/);
        if (match) {
          proxies.push({
            ip: match[1],
            port: match[2],
            type: defaultType,
            latency: null
          });
        }
      }
    }

    return proxies;
  }

  getTypeFromUrl(url) {
    if (url.includes('socks4')) return 'SOCKS4';
    if (url.includes('socks5')) return 'SOCKS5';
    if (url.includes('https')) return 'HTTPS';
    return 'HTTP';
  }

  async detectCountry(ip) {
    try {
      // Using a free IP geolocation API
      const response = await axios.get(`http://ip-api.com/json/${ip}`, { 
        timeout: 2000 
      });
      
      if (response.data && response.data.status === 'success') {
        return response.data.countryCode || response.data.country || 'UNKNOWN';
      }
    } catch (error) {
      // Silent fail - don't log to avoid spam
    }
    return 'UNKNOWN';
  }

  async testProxy(proxy) {
    return new Promise(async (resolve) => {
      const startTime = Date.now();
      
      // Detect country if not already set
      if (!proxy.country || proxy.country === 'UNKNOWN') {
        proxy.country = await this.detectCountry(proxy.ip);
      }
      
      tcpPing.ping({
        address: proxy.ip,
        port: parseInt(proxy.port),
        timeout: this.settings.testTimeout,
        attempts: 1
      }, (err, data) => {
        const endTime = Date.now();
        const latency = endTime - startTime;
  
        if (err || !data.min) {
          proxy.status = 'failed';
          proxy.latency = null;
        } else {
          proxy.latency = Math.round(data.min);
          if (proxy.latency < 500) {
            proxy.status = 'working';
          } else if (proxy.latency < 2000) {
            proxy.status = 'slow';
          } else {
            proxy.status = 'failed';
          }
        }
  
        proxy.lastChecked = new Date().toISOString();
        this.updateStats();
        resolve(proxy);
      });
    });
  }

  async testProxiesInBatches(batchSize = null) {
    const concurrentTests = batchSize || this.settings.concurrentTests || 100;
    const untested = this.proxies.filter(p => p.status === 'untested');
    
    console.log(`Testing ${untested.length} proxies with ${concurrentTests} concurrent tests...`);
    
    for (let i = 0; i < untested.length; i += concurrentTests) {
      const batch = untested.slice(i, i + concurrentTests);
      
      // Mark as testing
      batch.forEach(proxy => {
        proxy.status = 'testing';
      });
      this.updateStats();

      // Send progress to renderer
      if (global.mainWindow) {
        global.mainWindow.webContents.send('test-progress', {
          current: i,
          total: untested.length,
          percentage: Math.round((i / untested.length) * 100)
        });
      }

      // Test batch
      const promises = batch.map(proxy => this.testProxy(proxy));
      await Promise.all(promises);
      
      // Small delay between batches to prevent overwhelming the system
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    console.log('Proxy testing complete!');
    this.updateStats();
  }

  toggleProxy(proxyId) {
    const proxy = this.proxies.find(p => p.id === proxyId);
    if (proxy) {
      proxy.enabled = !proxy.enabled;
    }
    return proxy;
  }

  getNextWorkingProxy() {
    const workingProxies = this.proxies.filter(p => 
      p.enabled && 
      p.status === 'working' && 
      p.usageCount < this.settings.maxUsagePerProxy
    );

    if (workingProxies.length === 0) {
      return null;
    }

    if (this.settings.autoSwitch) {
      const proxy = workingProxies[this.settings.currentProxyIndex % workingProxies.length];
      proxy.usageCount++;
      this.settings.currentProxyIndex++;
      return proxy;
    } else {
      const proxy = workingProxies[0];
      proxy.usageCount++;
      return proxy;
    }
  }

  getNextProxyForTunnel() {
    const candidates = this.proxies.filter(p =>
      p.enabled &&
      p.status === 'working' &&
      p.usageCount < this.settings.maxUsagePerProxy &&
      (p.type === 'HTTP' || p.type === 'HTTPS')
    );

    if (candidates.length === 0) return this.getNextWorkingProxy();

    const proxy = candidates[this.settings.currentProxyIndex % candidates.length];
    proxy.usageCount++;
    this.settings.currentProxyIndex++;
    return proxy;
  }

  updateStats() {
    this.stats = {
      total: this.proxies.length,
      working: this.proxies.filter(p => p.status === 'working').length,
      failed: this.proxies.filter(p => p.status === 'failed').length,
      testing: this.proxies.filter(p => p.status === 'testing').length,
      untested: this.proxies.filter(p => p.status === 'untested').length,
      slow: this.proxies.filter(p => p.status === 'slow').length
    };
  }

  getProxies() {
    return this.proxies;
  }

  getStats() {
    return this.stats;
  }

  updateSettings(newSettings) {
    this.settings = { ...this.settings, ...newSettings };
    return this.settings;
  }

  getSettings() {
    return this.settings;
  }

  async saveProxiesToFile() {
    const filePath = path.join(process.cwd(), 'proxies.json');
    await fs.writeFile(filePath, JSON.stringify(this.proxies, null, 2));
  }

  async loadProxiesFromFile() {
    try {
      const filePath = path.join(process.cwd(), 'proxies.json');
      const data = await fs.readFile(filePath, 'utf-8');
      this.proxies = JSON.parse(data);
      this.updateStats();
    } catch (error) {
      console.error('Failed to load proxies from file:', error);
    }
  }
}

module.exports = ProxyManager;