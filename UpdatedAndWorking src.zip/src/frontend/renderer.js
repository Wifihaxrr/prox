const { ipcRenderer } = require('electron');

let currentTab = 'proxies';
let proxies = [];
let settings = {};
let animationFrame = null;

// Initialize with fancy animations
async function init() {
    showNotification('🚀 INITIALIZING QUANTUM PROXY SYSTEM...', 'success');
    
    await fancyLoad();
    
    await loadSettings();
    await loadProxies();
    await checkServerStatus(); // Add this
    updateStats();
    setInterval(updateStats, 5000);
    
    // Start background animations
    startBackgroundAnimations();
    
    showNotification('✅ SYSTEM READY - ALL SYSTEMS OPERATIONAL', 'success');
}

window.toggleProxy = async function(proxyId) {
    await ipcRenderer.invoke('toggle-proxy', proxyId);
    await loadProxies();
    
    const proxy = proxies.find(p => p.id === proxyId);
    if (proxy) {
        showNotification(`${proxy.enabled ? '✅' : '❌'} PROXY ${proxy.enabled ? 'ACTIVATED' : 'DEACTIVATED'}`, 'success');
    }
}

window.testProxy = async function(proxyId) {
    const proxy = proxies.find(p => p.id === proxyId);
    if (proxy) {
        showNotification(`🔍 TESTING ${proxy.ip}:${proxy.port}...`, 'success');
        await ipcRenderer.invoke('test-proxy', proxy);
        await loadProxies();
    }
}

async function checkServerStatus() {
    try {
        const status = await ipcRenderer.invoke('get-server-status');
        
        if (status.isRunning) {
            addLog(`>>> LOCAL PROXY SERVER: 127.0.0.1:${status.port} [ONLINE]`, 'success');
            addLog(`>>> INTERCEPTED REQUESTS: ${status.requestCount}`, 'info');
            
            // Update any server status displays
            updateServerStatusDisplay(status);
        } else {
            addLog('>>> LOCAL PROXY SERVER: [OFFLINE]', 'warning');
        }
    } catch (error) {
        console.error('Failed to check server status:', error);
    }
}

// Listen for server status updates
ipcRenderer.on('server-status', (event, status) => {
    if (status.isRunning) {
        addLog(`>>> PROXY SERVER AUTO-STARTED ON PORT ${status.port}`, 'success');
        updateServerStatusDisplay(status);
    }
});

// Update server status display
function updateServerStatusDisplay(status) {
    // Update settings page server status if visible
    const serverStatusElements = document.querySelectorAll('.server-status-display');
    serverStatusElements.forEach(element => {
        element.innerHTML = `
            <p style="color: #00ff88;">● SERVER ACTIVE: 127.0.0.1:${status.port}</p>
            <p>Requests Intercepted: ${status.requestCount}</p>
        `;
    });
    
    // Update or hide the start server button
    const startServerBtn = document.querySelector('[onclick="startProxyServer()"]');
    if (startServerBtn) {
        startServerBtn.innerHTML = `<span>✅ SERVER RUNNING ON :${status.port}</span>`;
        startServerBtn.style.background = 'linear-gradient(45deg, #00ff88, #00ff44)';
        startServerBtn.disabled = true;
    }
}


// Fancy loading animation
async function fancyLoad() {
    return new Promise(resolve => {
        const chars = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
        let i = 0;
        
        const interval = setInterval(() => {
            if (i >= 10) {
                clearInterval(interval);
                resolve();
            }
            i++;
        }, 100);
    });
}

// Fetch proxies with fancy animation
async function fetchProxies() {
    const button = event.target;
    button.disabled = true;
    button.innerHTML = '<span> SCANNING...</span>';
    
    // Show loading animation
    document.getElementById('loading-container').style.display = 'block';
    document.getElementById('proxy-table').style.opacity = '0.3';
    
    showNotification(' SCANNING GLOBAL PROXY NETWORKS...', 'success');
    
    try {
        proxies = await ipcRenderer.invoke('fetch-proxies');
        
        // Wait a moment for the backend to update
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Load the updated proxies
        await loadProxies();
        
        updateStats();
        addLog(`>>> SUCCESSFULLY ACQUIRED ${proxies.length} PROXIES`, 'success');
        showNotification(`✅ ${proxies.length} PROXIES LOADED INTO MATRIX`, 'success');
        
        // Set up interval to refresh the display during testing
        const refreshInterval = setInterval(async () => {
            await loadProxies();
            const stats = await ipcRenderer.invoke('get-stats');
            if (stats.testing === 0) {
                clearInterval(refreshInterval);
            }
        }, 2000); // Refresh every 2 seconds during testing
        
    } catch (error) {
        addLog(`>>> ERROR: ${error.message}`, 'error');
        showNotification('❌ PROXY FETCH FAILED', 'error');
    }
    
    document.getElementById('loading-container').style.display = 'none';
    document.getElementById('proxy-table').style.opacity = '1';
    
    button.disabled = false;
    button.innerHTML = '<span> FETCH PROXIES</span>';
}

async function renderProxyTableFancy() {
    const tbody = document.getElementById('proxy-table');
    tbody.innerHTML = '';
    
    const displayProxies = proxies.slice(0, 100); // Show more proxies
    
    displayProxies.forEach((proxy, i) => {
        const row = createProxyRow(proxy);
        tbody.appendChild(row);
        
        // Quick animation
        setTimeout(() => {
            row.style.opacity = '1';
        }, i * 10); // Faster animation
    });
}

function createProxyRow(proxy) {
    const row = document.createElement('tr');
    row.className = 'proxy-row';
    row.style.opacity = '0';
    row.style.transition = 'all 0.3s ease';
    
    // Ensure proxy has all required fields
    proxy = {
        status: 'untested',
        ip: 'Unknown',
        port: '0',
        type: 'HTTP',
        latency: null,
        country: 'UN',
        usageCount: 0,
        enabled: true,
        ...proxy // Override with actual proxy data
    };
    
    const statusClass = `status-${proxy.status}`;
    const latencyColor = !proxy.latency ? '#666' : 
                         proxy.latency < 100 ? '#00ff88' : 
                         proxy.latency < 500 ? '#ffbb00' : '#ff0044';
    
    // Mask IP address - show only first octet
    const maskedIp = proxy.ip.split('.').map((octet, index) => index === 0 ? octet : 'XXX').join('.');
    const latency = proxy.latency ? `${proxy.latency}ms` : '---';
    const maxUsage = settings.maxUsagePerProxy || 10;
    const usagePercent = Math.min((proxy.usageCount / maxUsage) * 100, 100);
    
    // Create cells as array to ensure exactly 7
    const cells = [
        // Cell 1: STATUS
        `<td style="padding: 15px;">
            <span class="status-orb ${statusClass}"></span>
            <span style="font-family: 'Orbitron', monospace; font-size: 12px; text-transform: uppercase;">
                ${proxy.status}
            </span>
        </td>`,
        
        // Cell 2: IP:PORT  
        `<td style="padding: 15px; font-family: 'Courier New', monospace; color: #00ffff;">
            ${maskedIp}:${proxy.port}
        </td>`,
        
        // Cell 3: TYPE
        `<td style="padding: 15px;">
            <span style="color: #ff00ff; font-size: 12px; font-weight: 700; text-transform: uppercase;">
                ${proxy.type}
            </span>
        </td>`,
        
        // Cell 4: LATENCY
        `<td style="padding: 15px; color: ${latencyColor}; font-weight: 700;">
            ${latency}
        </td>`,
        
        // Cell 5: USAGE
        `<td style="padding: 15px;">
            <div style="width: 100px; height: 20px; background: rgba(0, 255, 255, 0.1); 
                        border: 1px solid #00ffff; border-radius: 10px; position: relative; overflow: hidden;">
                <div style="width: ${usagePercent}%; 
                            height: 100%; background: linear-gradient(90deg, #00ffff, #ff00ff); 
                            border-radius: 10px; transition: width 0.3s ease;">
                </div>
                <span style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); 
                             font-size: 10px; color: white; text-shadow: 0 0 2px rgba(0,0,0,0.5);">
                    ${proxy.usageCount}/${maxUsage}
                </span>
            </div>
        </td>`,
        
        // Cell 6: COUNTRY
        `<td style="padding: 15px; font-family: 'Orbitron', monospace; font-size: 12px;">
            ${proxy.country}
        </td>`,
        
        // Cell 7: ACTIONS
        `<td style="padding: 15px;">
            <button onclick="window.toggleProxy('${proxy.id}')" 
                    style="padding: 5px 10px; margin-right: 5px; background: ${proxy.enabled ? '#00ff88' : '#ff0044'}; 
                           border: none; border-radius: 5px; color: white; cursor: pointer; font-weight: 700; 
                           font-size: 11px;">
                ${proxy.enabled ? 'ON' : 'OFF'}
            </button>
            <button onclick="window.testProxy('${proxy.id}')" 
                    style="padding: 5px 10px; background: #00bbff; border: none; border-radius: 5px; 
                           color: white; cursor: pointer; font-weight: 700; font-size: 11px;">
                TEST
            </button>
        </td>`
    ];
    
    // Join exactly 7 cells
    row.innerHTML = cells.join('');
    
    // Debug: Log to ensure we have exactly 7 cells
    console.log(`Row created with ${row.children.length} cells for proxy ${proxy.id}`);
    
    return row;
}

// Make sure these functions are globally accessible
window.toggleProxy = async function(proxyId) {
    await ipcRenderer.invoke('toggle-proxy', proxyId);
    await loadProxies();
    
    const proxy = proxies.find(p => p.id === proxyId);
    if (proxy) {
        showNotification(`${proxy.enabled ? '✅' : '❌'} PROXY ${proxy.enabled ? 'ACTIVATED' : 'DEACTIVATED'}`, 'success');
    }
}

window.testProxy = async function(proxyId) {
    const proxy = proxies.find(p => p.id === proxyId);
    if (proxy) {
        showNotification(`🔍 TESTING ${proxy.ip}:${proxy.port}...`, 'success');
        await ipcRenderer.invoke('test-proxy', proxy);
        await loadProxies();
    }
}

// Test all proxies with visual feedback
async function testAllProxies() {
    showNotification('🔬 INITIATING QUANTUM PROXY TESTING...', 'success');
    addLog('>>> BATCH TESTING INITIATED', 'info');
    
    for (let i = 0; i < Math.min(proxies.length, 100); i++) {
        await ipcRenderer.invoke('test-proxy', proxies[i]);
        
        if (i % 10 === 0) {
            await loadProxies();
            showNotification(`⚡ TESTED ${i + 1} PROXIES...`, 'success');
        }
    }
    
    showNotification('✅ PROXY TESTING COMPLETE', 'success');
    addLog('>>> BATCH TESTING COMPLETED', 'success');
}

// Toggle proxy with animation
async function toggleProxy(proxyId) {
    await ipcRenderer.invoke('toggle-proxy', proxyId);
    await loadProxies();
    
    const proxy = proxies.find(p => p.id === proxyId);
    if (proxy) {
        showNotification(`${proxy.enabled ? '✅' : '❌'} PROXY ${proxy.enabled ? 'ACTIVATED' : 'DEACTIVATED'}`, 'success');
    }
}

// Test single proxy
async function testProxy(proxyId) {
    const proxy = proxies.find(p => p.id === proxyId);
    if (proxy) {
        showNotification(`🔍 TESTING ${proxy.ip}:${proxy.port}...`, 'success');
        await ipcRenderer.invoke('test-proxy', proxy);
        await loadProxies();
    }
}

async function loadProxies() {
    try {
        proxies = await ipcRenderer.invoke('get-proxies');
        await renderProxyTableFancy();
        updateStats(); // Also update stats when loading proxies
    } catch (error) {
        console.error('Failed to load proxies:', error);
    }
}

// Update statistics with animations
async function updateStats() {
    try {
        const [stats, serverStatus] = await Promise.all([
            ipcRenderer.invoke('get-stats'),
            ipcRenderer.invoke('get-server-status')
        ]);
        
        // Proxies stats
        animateNumber('stat-total', stats.total);
        animateNumber('stat-working', stats.working);
        
        // Dax TLS counters
        if (serverStatus) {
            animateNumber('stat-dax-active', serverStatus.activeDaxConnections || 0);
            animateNumber('stat-dax-total', serverStatus.totalDaxCalls || 0);
        }
    } catch (error) {
        console.error('Failed to update stats:', error);
    }
}

// Animate number changes
function animateNumber(elementId, target) {
    const element = document.getElementById(elementId);
    if (!element) return; // Guard in case element not present
    const current = parseInt(element.textContent) || 0;
    const increment = (target - current) / 20;
    let step = 0;
    
    const timer = setInterval(() => {
        step++;
        const value = Math.round(current + increment * step);
        element.textContent = value;
        
        if (step >= 20) {
            element.textContent = target;
            clearInterval(timer);
        }
    }, 30);
}

// Load settings
async function loadSettings() {
    try {
        settings = await ipcRenderer.invoke('get-settings');
        document.getElementById('setting-max-usage').value = settings.maxUsagePerProxy;
        document.getElementById('setting-auto-switch').checked = settings.autoSwitch;
        document.getElementById('setting-timeout').value = settings.testTimeout;
        
        // Update toggle switch visual
        const toggle = document.querySelector('.toggle-switch');
        if (settings.autoSwitch && toggle) {
            toggle.classList.add('active');
        }
    } catch (error) {
        console.error('Failed to load settings:', error);
    }
}

// Save settings with fancy feedback
async function saveSettings() {
    const newSettings = {
        maxUsagePerProxy: parseInt(document.getElementById('setting-max-usage').value),
        autoSwitch: document.getElementById('setting-auto-switch').checked,
        testTimeout: parseInt(document.getElementById('setting-timeout').value)
    };
    
    await ipcRenderer.invoke('update-settings', newSettings);
    settings = newSettings;
    
    showNotification('⚙️ CONFIGURATION SAVED SUCCESSFULLY', 'success');
    addLog('>>> SYSTEM CONFIGURATION UPDATED', 'success');
}

// Export proxies
function exportProxies() {
    const data = proxies.map(p => `${p.ip}:${p.port}`).join('\n');
    const blob = new Blob([data], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'proxies_export.txt';
    a.click();
    
    showNotification('💾 PROXIES EXPORTED SUCCESSFULLY', 'success');
}

// Tab switching with animations
function switchTab(tab) {
    currentTab = tab;
    
    ['proxies', 'settings', 'monitor', 'logs'].forEach(t => {
        const btn = document.getElementById(`tab-${t}`);
        const content = document.getElementById(`content-${t}`);
        
        if (t === tab) {
            btn.classList.add('active');
            content.style.display = 'block';
            content.style.animation = 'fadeIn 0.5s ease';
        } else {
            btn.classList.remove('active');
            content.style.display = 'none';
        }
    });
    
    if (tab === 'monitor') {
        updateMonitor();
    }
}



ipcRenderer.on('test-progress', (event, data) => {
  const progressText = `Testing proxies: ${data.current}/${data.total} (${data.percentage}%)`;
  showNotification(progressText, 'info');
  
  // Update UI with progress
  const loadingContainer = document.getElementById('loading-container');
  if (loadingContainer) {
    const progressBar = loadingContainer.querySelector('.progress-bar');
    if (progressBar) {
      progressBar.style.width = `${data.percentage}%`;
    }
  }
  
  // Refresh the proxy table periodically during testing to show updated results
  if (data.percentage % 10 === 0 || data.percentage === 100) {
    loadProxies(); // Refresh proxy table every 10% or when complete
  }
  
  // Update stats during testing
  updateStats();
});

// Enhanced monitor update to show more details
async function updateMonitor() {
    try {
        // Get server status first
        const serverStatus = await ipcRenderer.invoke('get-server-status');
        
        // Update server info in monitor
        const serverInfoDiv = document.getElementById('server-info');
        if (serverInfoDiv) {
            serverInfoDiv.innerHTML = `
                <div style="padding: 10px; background: rgba(0, 255, 255, 0.1); border-radius: 10px; margin-bottom: 20px;">
                    <h4 style="color: #00ffff;">Proxy Server Status</h4>
                    <p>Status: <span style="color: ${serverStatus.isRunning ? '#00ff88' : '#ff0044'};">
                        ${serverStatus.isRunning ? '● ONLINE' : '● OFFLINE'}
                    </span></p>
                    <p>Port: ${serverStatus.port || 'N/A'}</p>
                    <p>Total Requests: ${serverStatus.requestCount || 0}</p>
                </div>
            `;
        }
        
        // Get intercepted requests
        const result = await ipcRenderer.invoke('get-intercepted-requests');
        const container = document.getElementById('intercepted-requests');
        
        if (container) {
            if (result.requests && result.requests.length > 0) {
                const recentRequests = result.requests.slice(-10).reverse();
                container.innerHTML = recentRequests.map(req => `
                    <div style="padding: 10px; border-bottom: 1px solid rgba(0, 255, 255, 0.2); 
                                display: flex; justify-content: space-between; align-items: center;">
                        <span style="color: #00ff88; font-weight: bold; min-width: 60px;">${req.method}</span>
                        <span style="color: #00ffff; flex: 1; margin: 0 10px; 
                                   overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                            ${req.host || 'localhost'}${req.url}
                        </span>
                        <span style="color: #ffbb00; font-size: 12px;">
                            ${new Date(req.timestamp).toLocaleTimeString()}
                        </span>
                    </div>
                `).join('');
            } else {
                container.innerHTML = `
                    <div style="text-align: center; padding: 20px; color: #666;">
                        <p>No intercepted requests yet.</p>
                        <p style="margin-top: 10px;">Server is running on port ${serverStatus.port || '443'}</p>
                        <button onclick="testProxyServer()" 
                                style="margin-top: 10px; padding: 8px 16px; background: #00bbff; 
                                       border: none; border-radius: 5px; color: white; cursor: pointer;">
                            Send Test Request
                        </button>
                    </div>
                `;
            }
        }

        // Update charts
        await updateTrafficChart();
        await updateProxyDistribution();
        
    } catch (error) {
        console.error('Failed to update monitor:', error);
    }
}

async function updateTrafficChart() {
    const canvas = document.getElementById('traffic-chart');
    
    if (canvas && canvas.getContext) {
        const ctx = canvas.getContext('2d');
        
        // Set canvas size to fill container
        const container = canvas.parentElement;
        canvas.width = container.clientWidth - 40;
        canvas.height = container.clientHeight - 60;
        
        // Clear canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Draw grid
        ctx.strokeStyle = 'rgba(0, 255, 255, 0.1)';
        ctx.lineWidth = 1;
        
        // Vertical lines
        for (let x = 0; x < canvas.width; x += 40) {
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, canvas.height);
            ctx.stroke();
        }
        
        // Horizontal lines
        for (let y = 0; y < canvas.height; y += 40) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(canvas.width, y);
            ctx.stroke();
        }
        
        // Generate random traffic data
        const dataPoints = [];
        for (let i = 0; i < 50; i++) {
            dataPoints.push({
                x: (canvas.width / 50) * i,
                y: canvas.height / 2 + (Math.sin(i * 0.2) * (canvas.height / 3)) + (Math.random() - 0.5) * 20
            });
        }
        
        // Draw the traffic line
        ctx.strokeStyle = '#00ffff';
        ctx.lineWidth = 3;
        ctx.shadowBlur = 20;
        ctx.shadowColor = '#00ffff';
        
        ctx.beginPath();
        dataPoints.forEach((point, index) => {
            if (index === 0) {
                ctx.moveTo(point.x, point.y);
            } else {
                const prev = dataPoints[index - 1];
                const cp1x = prev.x + (point.x - prev.x) / 2;
                const cp1y = prev.y;
                const cp2x = prev.x + (point.x - prev.x) / 2;
                const cp2y = point.y;
                ctx.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, point.x, point.y);
            }
        });
        ctx.stroke();
        
        // Draw glow effect
        ctx.strokeStyle = 'rgba(0, 255, 255, 0.3)';
        ctx.lineWidth = 8;
        ctx.shadowBlur = 30;
        ctx.stroke();
        
        // Add labels
        ctx.shadowBlur = 0;
        ctx.fillStyle = '#00ffff';
        ctx.font = '12px Orbitron';
        ctx.fillText('100%', 5, 15);
        ctx.fillText('50%', 5, canvas.height / 2);
        ctx.fillText('0%', 5, canvas.height - 5);
        
        // Time labels
        ctx.fillText('Now', canvas.width - 30, canvas.height - 5);
        ctx.fillText('-30s', 5, canvas.height - 5);
    }
}

async function testProxyServer() {
    try {
        // Add a test request
        await ipcRenderer.invoke('add-test-request');
        
        // Make a test HTTP request to the proxy
        const status = await ipcRenderer.invoke('get-server-status');
        if (status.isRunning) {
            fetch(`http://127.0.0.1:${status.port}/test`)
                .then(() => console.log('Test request sent'))
                .catch(err => console.log('Test request failed:', err));
        }
        
        showNotification('📡 Test request sent to proxy server', 'info');
        
        // Refresh monitor after a short delay
        setTimeout(() => updateMonitor(), 500);
    } catch (error) {
        console.error('Failed to test proxy server:', error);
    }
}

async function startProxyServer() {
    const button = event.target;
    button.disabled = true;
    button.innerHTML = '<span> CHECKING...</span>';
    
    try {
        const result = await ipcRenderer.invoke('start-proxy-server');
        
        if (result.success) {
            if (result.alreadyRunning) {
                showNotification(`ℹ️ Server already running on port ${result.port}`, 'info');
                button.innerHTML = `<span>✅ ALREADY RUNNING ON :${result.port}</span>`;
            } else {
                showNotification(`✅ Proxy server started on port ${result.port}!`, 'success');
                button.innerHTML = `<span>✅ RUNNING ON :${result.port}</span>`;
            }
            
            button.style.background = 'linear-gradient(45deg, #00ff88, #00ff44)';
            addLog(`>>> PROXY SERVER STATUS: 127.0.0.1:${result.port}`, 'success');
            
            // Update server status display
            const status = await ipcRenderer.invoke('get-server-status');
            updateServerStatusDisplay(status);
        } else {
            showNotification(`❌ Failed to start: ${result.error}`, 'error');
            button.disabled = false;
            button.innerHTML = '<span>🚀 START PROXY SERVER</span>';
        }
    } catch (error) {
        showNotification('❌ Failed to start proxy server', 'error');
        button.disabled = false;
        button.innerHTML = '<span>🚀 START PROXY SERVER</span>';
    }
}

async function updateProxyDistribution() {
    const stats = await ipcRenderer.invoke('get-stats');
    const canvas = document.getElementById('distribution-chart');
    
    if (canvas && canvas.getContext) {
        const ctx = canvas.getContext('2d');
        
        // Set canvas size to fill container
        const container = canvas.parentElement;
        canvas.width = container.clientWidth - 40;
        canvas.height = container.clientHeight - 60;
        
        // Clear canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Calculate percentages
        const total = stats.total || 1;
        const data = [
            { label: 'Working', value: stats.working, color: '#00ff88' },
            { label: 'Failed', value: stats.failed, color: '#ff0044' },
            { label: 'Testing', value: stats.testing, color: '#ffbb00' },
            { label: 'Untested', value: stats.untested || (total - stats.working - stats.failed - stats.testing), color: '#666' }
        ];
        
        // Draw pie chart - make it bigger
        let currentAngle = -Math.PI / 2;
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2 - 20;
        const radius = Math.min(canvas.width, canvas.height - 40) / 2.5;
        
        // Draw shadow
        ctx.shadowBlur = 30;
        ctx.shadowColor = 'rgba(0, 255, 255, 0.3)';
        
        data.forEach(segment => {
            if (segment.value > 0) {
                const angle = (segment.value / total) * Math.PI * 2;
                
                // Draw segment
                ctx.beginPath();
                ctx.moveTo(centerX, centerY);
                ctx.arc(centerX, centerY, radius, currentAngle, currentAngle + angle);
                ctx.closePath();
                ctx.fillStyle = segment.color;
                ctx.fill();
                
                // Draw border
                ctx.strokeStyle = 'rgba(0, 255, 255, 0.5)';
                ctx.lineWidth = 2;
                ctx.stroke();
                
                // Draw percentage in segment
                const labelAngle = currentAngle + angle / 2;
                const labelX = centerX + Math.cos(labelAngle) * (radius * 0.6);
                const labelY = centerY + Math.sin(labelAngle) * (radius * 0.6);
                
                ctx.shadowBlur = 0;
                ctx.fillStyle = '#fff';
                ctx.font = 'bold 16px Orbitron';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                const percentage = Math.round((segment.value / total) * 100);
                if (percentage > 5) { // Only show if segment is big enough
                    ctx.fillText(`${segment.value}`, labelX, labelY);
                    ctx.font = '10px Orbitron';
                    ctx.fillText(`${percentage}%`, labelX, labelY + 15);
                }
                
                currentAngle += angle;
            }
        });
        
        // Draw center circle for donut effect
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius * 0.3, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(10, 10, 30, 0.9)';
        ctx.fill();
        ctx.strokeStyle = '#00ffff';
        ctx.lineWidth = 2;
        ctx.stroke();
        
        // Draw total in center
        ctx.fillStyle = '#00ffff';
        ctx.font = 'bold 24px Orbitron';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(total.toString(), centerX, centerY - 5);
        ctx.font = '10px Orbitron';
        ctx.fillText('TOTAL', centerX, centerY + 15);
        
        // Draw legend at bottom
        const legendY = canvas.height - 20;
        let legendX = 20;
        
        ctx.font = '12px Rajdhani';
        ctx.textAlign = 'left';
        
        data.forEach(segment => {
            // Draw color box
            ctx.fillStyle = segment.color;
            ctx.fillRect(legendX, legendY, 15, 15);
            
            // Draw label
            ctx.fillStyle = '#fff';
            ctx.fillText(`${segment.label}: ${segment.value}`, legendX + 20, legendY + 11);
            
            legendX += 120;
        });
    }
}

// Auto-refresh monitor when tab is active
let monitorInterval = null;

function switchTab(tab) {
  // Clear existing interval
  if (monitorInterval) {
    clearInterval(monitorInterval);
    monitorInterval = null;
  }
  
  currentTab = tab;
  
  ['proxies', 'settings', 'monitor', 'logs'].forEach(t => {
    const btn = document.getElementById(`tab-${t}`);
    const content = document.getElementById(`content-${t}`);
    
    if (t === tab) {
      btn.classList.add('active');
      content.style.display = 'block';
      content.style.animation = 'fadeIn 0.5s ease';
    } else {
      btn.classList.remove('active');
      content.style.display = 'none';
    }
  });
  
  if (tab === 'monitor') {
    updateMonitor();
    // Auto-refresh every 2 seconds
    monitorInterval = setInterval(updateMonitor, 2000);
  }
}

// Enhanced log system
function addLog(message, type = 'info') {
    const logContainer = document.getElementById('log-container');
    const timestamp = new Date().toLocaleTimeString();
    const logEntry = document.createElement('div');
    
    const colors = {
        info: '#00bbff',
        success: '#00ff88',
        error: '#ff0044',
        warning: '#ffbb00'
    };
    
    logEntry.style.color = colors[type] || '#00ffff';
    logEntry.innerHTML = `[${timestamp}] ${message}`;
    logEntry.style.animation = 'slideIn 0.3s ease';
    
    if (logContainer) {
        logContainer.appendChild(logEntry);
        logContainer.scrollTop = logContainer.scrollHeight;
    }
}

// Background animations
function startBackgroundAnimations() {
    // Add random glitch effects
    setInterval(() => {
        if (Math.random() > 0.95) {
            document.body.style.animation = 'glitch 0.3s';
            setTimeout(() => {
                document.body.style.animation = '';
            }, 300);
        }
    }, 3000);
}



// Window controls
function minimizeWindow() {
    ipcRenderer.send('minimize-window');
}

function maximizeWindow() {
    ipcRenderer.send('maximize-window');
}

function closeWindow() {
    if (confirm('Are you sure you want to exit DAX Pro?')) {
        ipcRenderer.send('close-window');
    }
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateX(-50px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
    
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    
    @keyframes glitch {
        0%, 100% { transform: translate(0); }
        20% { transform: translate(-2px, 2px); }
        40% { transform: translate(-2px, -2px); }
        60% { transform: translate(2px, 2px); }
        80% { transform: translate(2px, -2px); }
    }
`;
document.head.appendChild(style);

// Initialize on load
window.addEventListener('DOMContentLoaded', init);